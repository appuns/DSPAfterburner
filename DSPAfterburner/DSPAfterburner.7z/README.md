# DSP Afterburner
Want to fly faster in flight mode too!. This don't affect achievements or milestones.<br>
飛行モードでももっと速く飛びたい！。実績やマイルストーンには影響しません。<br>

## Features　特徴
Press left SHIFT to increase speed by 2.5 times in flight mode. It also consumes a lot of energy. This don't affect achievements or milestones.<br>
You can change the key, magnification, and maximum speed, but if it is too fast, it will exceed the first cosmic speed.
After first time you launch the game with this mod, the config file will be generated.
steamapps/common/Dyson Sphere Program/config/Appun.DSP.plugin.Afterburner.cfg<br>
<br>
飛行モードの時に左SHIFTを押すと2.5倍のスピードになります。エネルギーもたくさん消費します。実績やマイルストーンには影響しません。<br>
キーや倍率や最高速度を変更することができますが、速すぎると第１宇宙速度を超えてしまいます。
初回起動後に次のコンフィグファイルが自動的に作成されます。<br>
steamapps/common/Dyson Sphere Program/config/Appun.DSP.plugin.Afterburner.cfg<br>

## How to install　インストール方法
1. Install BepInEx<br>w
2. Drag DSPAfterburner.dll into steamapps/common/Dyson Sphere Program/BepInEx/plugins<br>
<br>
1. BepInExをインストールします。<br>
2. DSPAfterburner.dllをsteamapps/common/Dyson Sphere Program/BepInEx/pluginsに配置します。<br>
<br>
## Contact 問い合わせ先
If you have any problems or suggestions, please contact DISCORD MSP Modding server **Appun#8284**.<br>
不具合、改善案などありましたら、DISCORD「DysonSphereProgram_Jp」サーバー**Appun#8284**までお願いします。<br>
<br>
## Change Log　更新履歴
### v0.0.1
- released, Supported the game version 0.10.28.21172. リリースしました。ゲームバージョン0.10.28.21172に対応しています。
